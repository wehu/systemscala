package systemscala

object Main extends App {
  Simulate.run{
    var b: Thread = null
    val a = Thread {
      println("a")
      Thread.sleep
      println("a")
    }
    b = Thread {
      println("b")
      Thread.wake(a)
      println("b")
    }
    val e = Event("event 0")
    e.subscribe { println("eeee")}
    e._notify
  }
}