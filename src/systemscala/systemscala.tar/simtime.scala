package systemscala

class SimTime(val delay: Int = 0) extends Event {
  val st = SimTime.timeline + delay * SimTime.timescale
  SimTime.sts.get(st) match {
    case None => var q = new SimTime.Queue
      q += this
      SimTime.sts += (st -> q) 
    case Some(q) => q += this
  }
  override def _notify {
    super._notify
    Event.remove(this)
    SimTime.sts -= st
  }
}

object SimTime {
  type Queue = scala.collection.mutable.Queue[SimTime]
  var timeline = 0
  var timescale = 1
  var sts = scala.collection.mutable.Map[Int, Queue]()
  def apply(delay: Int = 0) : SimTime = {
    new SimTime(delay)
  }
  def remove(time: Int){
    sts -= time
  }
}

object Simulate {
  def run(body: => Unit){
    Thread.run{
      var sl:()=>Unit = null
      sl = ()=>{
        Thread{sl()}
      } : Unit
      body
    }
  }
}